<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class contribuyente extends Model
{
    public $table = 'contribuyente';
    public $timestamps = false;
}
