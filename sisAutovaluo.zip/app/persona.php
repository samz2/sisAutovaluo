<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class persona extends Model
{
    public $table = 'persona';
    public $timestamps = false;
}
