<?php $__env->startSection('content'); ?>
    <router-view></router-view>
    <vue-progress-bar></vue-progress-bar>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>